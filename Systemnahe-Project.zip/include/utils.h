#ifndef UTILS_H
#define UTILS_H

void parse_arguments(int argc, char *argv[]);

#endif

