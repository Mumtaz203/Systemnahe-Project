#ifndef FILE_OPERATIONS_H
#define FILE_OPERATIONS_H

void traverse_directory(const char *path);

#endif

